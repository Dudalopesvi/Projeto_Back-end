import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';

import statusRoutes from './routes/statusRoutes.js';
import empresaRoutes from './routes/empresaRoutes.js';
import atividadesRoutes from './routes/atividadesRoutes.js';

dotenv.config();

const app = express();

app.use(cors());
app.use(express.json());

// Importação e vinculação dos 3 módulos de rotas
app.use('/status', statusRoutes);
app.use('/empresa', empresaRoutes);
app.use('/atividades', atividadesRoutes);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Servidor rodando na porta ${PORT}`);
});