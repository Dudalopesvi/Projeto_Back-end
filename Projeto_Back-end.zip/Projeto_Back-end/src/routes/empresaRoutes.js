import { Router } from 'express';
import { getEmpresaPerfil } from '../controllers/empresaController.js';

const router = Router();

router.get('/', getEmpresaPerfil);

export default router;