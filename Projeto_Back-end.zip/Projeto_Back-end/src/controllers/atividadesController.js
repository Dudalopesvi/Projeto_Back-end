import pool from '../config/db.js';

export const getAtividades = async(req, res) => {
    try {
        const { pagina = 1, tipo } = req.query;
        const limite = 4; // Paginação de 4 itens por página (Item 4.2)
        const offset = (parseInt(pagina, 10) - 1) * limite;

        let queryBase = `
      SELECT 
        a.id_atividade,
        a.tipo,
        a.descricao,
        a.distancia,
        a.duracao,
        TO_CHAR(a.data_atividade, 'HH24:MI - DD/MM/YY') AS data_formatada,
        u.nome AS usuario_nome
      FROM atividades a
      JOIN usuarios u ON u.id_usuario = a.id_usuario
    `;

        const params = [];
        if (tipo) {
            params.push(`%${tipo}%`);
            queryBase += ` WHERE LOWER(a.tipo) LIKE LOWER($${params.length})`;
        }

        queryBase += ` ORDER BY a.data_atividade DESC LIMIT $${params.length + 1} OFFSET $${params.length + 2}`;
        params.push(limite, offset);

        const result = await pool.query(queryBase, params);

        return res.status(200).json({
            paginaAtual: parseInt(pagina, 10),
            itensPorPagina: limite,
            resultados: result.rows
        });
    } catch (error) {
        console.error('Erro ao listar atividades:', error);
        return res.status(500).json({ mensagem: 'Erro interno ao buscar atividades' });
    }
};