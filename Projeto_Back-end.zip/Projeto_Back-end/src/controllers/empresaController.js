import pool from '../config/db.js';

export const getEmpresaPerfil = async(req, res) => {
    try {
        const query = `
      SELECT 
        COUNT(a.id_atividade) AS total_atividades,
        COALESCE(SUM(a.duracao), 0) AS total_minutos,
        COALESCE(SUM(a.distancia), 0) AS total_distancia_km
      FROM atividades a;
    `;
        const result = await pool.query(query);
        const stats = result.rows[0];
        const estimativaCalorias = Math.round(stats.total_minutos * 7);

        return res.status(200).json({
            nome: 'SAEPSaúde',
            logo: '/assets/logo.png',
            totais: {
                atividades: parseInt(stats.total_atividades, 10),
                distanciaKm: parseFloat(stats.total_distancia_km),
                tempoMinutos: parseInt(stats.total_minutos, 10),
                caloriasEstimadas: estimativaCalorias
            }
        });
    } catch (error) {
        console.error('Erro ao buscar perfil da empresa:', error);
        return res.status(500).json({ mensagem: 'Erro interno no servidor' });
    }
};